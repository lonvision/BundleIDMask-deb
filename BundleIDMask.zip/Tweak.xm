/*
 * BundleIDMask.xm
 *
 * 目的：多开包（改过 CFBundleIdentifier）在运行时把读取到的 bundle id
 *       伪装回官方值 com.tencent.xin，用于验证「该账号尚未获得体验资格」
 *       是否由包标识差异触发。
 *
 * 覆盖路径：
 *   1) ObjC  -[NSBundle bundleIdentifier]        （仅 mainBundle）
 *   2) ObjC  -[NSBundle objectForInfoDictionaryKey:]  （仅 mainBundle）
 *   3) ObjC  -[NSBundle infoDictionary]          （仅 mainBundle）
 *   4) C     CFBundleGetIdentifier               （含 main bundle 判定）
 *   5) C     CFBundleGetValueForInfoDictionaryKey
 *
 * 设计要点：
 *   - 只作用于 mainBundle，避免影响微信内部加载的其它 bundle / framework
 *   - 只在值以 com.tencent.xin 开头且不等于官方值时改写
 *   - %ctor 里用 dlsym 拿原始函数读真实值打日志，不受 hook 影响
 *   - 本 tweak 仅由 BundleIDMask.plist 的 Filter.Bundles 限定在微信进程加载
 */

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/runtime.h>
#import <substrate.h>
#import <dlfcn.h>

// 目标官方 bundle id
static NSString *const kRealBundleID = @"com.tencent.xin";

// 原始函数指针（dlsym 取得，供 %ctor 阶段打日志用）
static CFStringRef (*p_CFBundleGetIdentifier)(CFBundleRef);
static CFTypeRef   (*p_CFBundleGetValueForInfoDictionaryKey)(CFBundleRef, CFStringRef);

static BOOL isWeChatBundleID(NSString *bid) {
    if (![bid isKindOfClass:[NSString class]]) return NO;
    return [bid hasPrefix:kRealBundleID];
}

// 需要改写吗：微信前缀 且 不等于官方值
static BOOL needMask(NSString *bid) {
    return isWeChatBundleID(bid) && ![bid isEqualToString:kRealBundleID];
}

static void LogBID(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    NSLog(@"[BundleIDMask] %@", msg);
}

// 判断是否 main bundle（instance 身份比较，开销极低）
static BOOL isMainBundle(NSBundle *b) {
    if (!b) return NO;
    return b == [NSBundle mainBundle];
}

#pragma mark - ObjC hooks

%hook NSBundle

- (NSString *)bundleIdentifier {
    NSString *orig = %orig;
    if (isMainBundle(self) && needMask(orig)) {
        return kRealBundleID;
    }
    return orig;
}

- (id)objectForInfoDictionaryKey:(NSString *)key {
    id v = %orig;
    if (isMainBundle(self) &&
        [key isEqualToString:@"CFBundleIdentifier"] &&
        [v isKindOfClass:[NSString class]] &&
        needMask(v)) {
        return kRealBundleID;
    }
    return v;
}

- (NSDictionary *)infoDictionary {
    NSDictionary *orig = %orig;
    if (!isMainBundle(self) || ![orig isKindOfClass:[NSDictionary class]]) {
        return orig;
    }

    id bid = orig[@"CFBundleIdentifier"];
    if ([bid isKindOfClass:[NSString class]] && needMask(bid)) {
        NSMutableDictionary *m = [orig mutableCopy];
        m[@"CFBundleIdentifier"] = kRealBundleID;
        return m;
    }
    return orig;
}

%end

#pragma mark - CoreFoundation hooks

static CFStringRef hook_CFBundleGetIdentifier(CFBundleRef bundle) {
    CFStringRef r = p_CFBundleGetIdentifier ? p_CFBundleGetIdentifier(bundle) : NULL;
    if (!r) return r;

    // 只处理 main bundle
    if (bundle != CFBundleGetMainBundle()) return r;

    NSString *s = (__bridge NSString *)r;
    if (needMask(s)) {
        return (__bridge CFStringRef)kRealBundleID;
    }
    return r;
}

static CFTypeRef hook_CFBundleGetValueForInfoDictionaryKey(CFBundleRef bundle, CFStringRef key) {
    CFTypeRef r = p_CFBundleGetValueForInfoDictionaryKey
                    ? p_CFBundleGetValueForInfoDictionaryKey(bundle, key)
                    : NULL;

    if (!key || !CFEqual(key, kCFBundleIdentifierKey)) return r;
    if (bundle != CFBundleGetMainBundle()) return r;

    if (r == NULL) {
        return (__bridge CFTypeRef)kRealBundleID;
    }
    NSString *s = (__bridge NSString *)r;
    if ([s isKindOfClass:[NSString class]] && needMask(s)) {
        return (__bridge CFTypeRef)kRealBundleID;
    }
    return r;
}

#pragma mark - Init

%ctor {
    @autoreleasepool {
        // 用 dlsym 拿原始实现，此时 hook 尚未安装，读到的是真实值
        p_CFBundleGetIdentifier =
            (CFStringRef (*)(CFBundleRef))dlsym(RTLD_DEFAULT, "CFBundleGetIdentifier");
        p_CFBundleGetValueForInfoDictionaryKey =
            (CFTypeRef (*)(CFBundleRef, CFStringRef))
            dlsym(RTLD_DEFAULT, "CFBundleGetValueForInfoDictionaryKey");

        LogBID(@"loaded, pid=%d", getpid());

        // 打印 Info.plist 里的真实值（走 CF 原始函数，绕过 hook）
        CFBundleRef mb = CFBundleGetMainBundle();
        if (mb && p_CFBundleGetValueForInfoDictionaryKey) {
            CFTypeRef v = p_CFBundleGetValueForInfoDictionaryKey(mb, kCFBundleIdentifierKey);
            LogBID(@"REAL CFBundleIdentifier = %@", (__bridge id)v);
        } else {
            LogBID(@"warn: CFBundleGetValueForInfoDictionaryKey unavailable");
        }

        // 安装 C 层 hook
        if (p_CFBundleGetIdentifier) {
            MSHookFunction((void *)p_CFBundleGetIdentifier,
                           (void *)hook_CFBundleGetIdentifier,
                           (void **)&p_CFBundleGetIdentifier);
            LogBID(@"hooked CFBundleGetIdentifier");
        }

        if (p_CFBundleGetValueForInfoDictionaryKey) {
            MSHookFunction((void *)p_CFBundleGetValueForInfoDictionaryKey,
                           (void *)hook_CFBundleGetValueForInfoDictionaryKey,
                           (void **)&p_CFBundleGetValueForInfoDictionaryKey);
            LogBID(@"hooked CFBundleGetValueForInfoDictionaryKey");
        }

        // 验证：装完 hook 后再读，应得到官方值
        NSString *after = [[NSBundle mainBundle] bundleIdentifier];
        LogBID(@"masked bundleIdentifier = %@ (expect %@)", after, kRealBundleID);
    }
}
