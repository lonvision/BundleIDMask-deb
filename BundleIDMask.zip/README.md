# BundleIDMask

微信多开包的 bundle id 伪装 tweak。用于验证「该账号尚未获得体验资格，无法使用该微信测试版本」是否由包标识（CFBundleIdentifier）差异触发。

## 背景

微信 8.0.78 主二进制里**没有**本地 bundle id 校验（已逐项核实：

- `CFBundleIdentifier` 仅 1 处代码引用，属 KSCrash 崩溃报告字段
- `bundleIdentifier` 选择器仅 1 个 selref，属 VoIP 推送注册
- `bundle id不匹配` 那句属优图 SDK 授权报错，非登录逻辑

）。但客户端会把 bundle id 作为构建标识上报，服务端可能据此判定包身份。

本 tweak 的作用：`Info.plist` 里保留你改过的值（系统层面能装两份），运行时让微信读到的始终是 `com.tencent.xin`。

## 覆盖的读取路径

| # | 路径 | 说明 |
|---|---|---|
| 1 | `-[NSBundle bundleIdentifier]` | ObjC 最常用 |
| 2 | `-[NSBundle objectForInfoDictionaryKey:]` | 键为 `CFBundleIdentifier` 时改写 |
| 3 | `-[NSBundle infoDictionary]` | 整体字典里的值改写 |
| 4 | `CFBundleGetIdentifier` | C API |
| 5 | `CFBundleGetValueForInfoDictionaryKey` | C API，含 `kCFBundleIdentifierKey` |

只对以 `com.tencent.xin` 开头的值生效，不影响其它 App。

## 编译

### 方式一：GitHub Actions（推荐）

推到 GitHub 后自动编译，在 Actions 页面下载 artifact：

- `BundleIDMask-deb` — 直接 `dpkg -i` 安装
- `BundleIDMask-dylib` — 手动放进 `/Library/MobileSubstrate/DynamicLibraries/`

### 方式二：本地 theos

```bash
export THEOS=~/theos
export PATH=$THEOS/bin:$PATH

make clean
make package FINALPACKAGE=1
```

产出 `packages/com.user.bundleidmask_1.0.0_iphoneos-arm64.deb`。

## 安装

```bash
# 越狱设备（Dopamine / palera1n / unc0ver）
scp packages/*.deb root@<device-ip>:/tmp/
ssh root@<device-ip>
dpkg -i /tmp/com.user.bundleidmask_*.deb
killall -9 WeChat
```

或直接手动放 dylib：

```bash
scp .theos/obj/BundleIDMask.dylib root@<device>:/Library/MobileSubstrate/DynamicLibraries/
scp BundleIDMask.plist root@<device>:/Library/MobileSubstrate/DynamicLibraries/
ssh root@<device> "chmod 644 /Library/MobileSubstrate/DynamicLibraries/BundleIDMask.*"
```

## 验证生效

装完启动微信，控制台应出现：

```
[BundleIDMask] loaded, pid=1234
[BundleIDMask] real bundleIdentifier = com.tencent.xin.wx2
[BundleIDMask] real info CFBundleIdentifier = com.tencent.xin.wx2
[BundleIDMask] CF hook installed
```

`real` 那两行显示的是**改过的值**（证明 Info.plist 确实是 wx2），但微信后续读到的都会被改写回 `com.tencent.xin`。

看日志：

```bash
# 实时看
idevicesyslog | grep BundleIDMask

# 或
ssh root@<device> "tail -f /var/log/syslog | grep BundleIDMask"
```

## 对照实验

```
A 组：只装 wechat_multi.ipa（bundle id = com.tencent.xin.wx2）
      登录 → 记录现象

B 组：加装 BundleIDMask
      登录 → 记录现象

判定：
  A 弹、B 不弹  → 包标识触发，本 tweak 有效
  A 弹、B 也弹  → 账号白名单问题，改包无用
```

## 注意

- 需要越狱（CydiaSubstrate / libhooker / ellekit 任一）
- 只在 64 位设备（`arm64` / `arm64e`）编译
- 最低 iOS 15.0（与微信 8.0.78 的 `MinimumOSVersion` 一致）
- 本 tweak 只做 bundle id 伪装，不碰登录逻辑、不碰风控上报
