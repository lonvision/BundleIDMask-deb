## 需要设置的环境变量

`THEOS` = `/opt/theos`（或 `$HOME/theos`）

## 本地编译

```bash
export THEOS=$HOME/theos
export PATH=$THEOS/bin:$PATH
make clean && make package FINALPACKAGE=1
```

## GitHub Actions

推送到 `main` 分支自动触发，产物在 Actions 页面的 artifact 中。
